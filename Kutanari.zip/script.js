// script.js
console.log("Selamat datang di portofolio saya!");
